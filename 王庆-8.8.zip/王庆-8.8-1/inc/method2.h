#ifndef __METHOD2_H__
#define __METHOD2_H__

void method2_memcpy(char *buffer, float f1, float f2);
void method2_extract(char *buffer, float *f1, float *f2);

#endif