#ifndef __METHOD3_H__
#define __METHOD3_H__

void method3_memcpy(char *buffer, float f1, float f2);
void method3_extract(char *buffer, float *f1, float *f2);

#endif