#include "main.h"
#include "method1.h"

#pragma pack(1)
typedef struct
{
    int a;
    char b;
    short c;
}A;

int main(){
    char buffer[8] = {0};
    float original[2] = {3.14159f, 2.71828f};
    method1_memcpy(buffer, original[0], original[1]);
    float extracted[2] = {0};
    method1_extract(buffer, &extracted[0], &extracted[1]);
    printf("extracted[0] = %f, extracted[1] = %f\r\n", extracted[0], extracted[1]);
    double diff1 = fabs(original[0] - extracted[0]);
    double diff2 = fabs(original[1] - extracted[1]);
    printf("Method1 Difference: %.10f, %.10f\r\n", diff1, diff2);
    return 0;
}