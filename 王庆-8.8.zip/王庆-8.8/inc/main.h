#ifndef __MAIN_H
#define __MAIN_H

#include "stdint.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

#endif
