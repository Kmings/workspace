#ifndef __METHOD1_H__
#define __METHOD1_H__

void method1_memcpy(char *buffer, float f1, float f2);

void method1_extract(char *buffer, float *f1, float *f2);

#endif
