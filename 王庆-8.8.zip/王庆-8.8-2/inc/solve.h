#ifndef SOLVE_H
#define SOLVE_H

#include "vector_math.h"

#endif